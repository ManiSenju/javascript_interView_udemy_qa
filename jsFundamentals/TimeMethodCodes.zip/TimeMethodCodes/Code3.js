let dt = new Date();
console.log(dt);
dt.setTime(0);
console.log(dt);