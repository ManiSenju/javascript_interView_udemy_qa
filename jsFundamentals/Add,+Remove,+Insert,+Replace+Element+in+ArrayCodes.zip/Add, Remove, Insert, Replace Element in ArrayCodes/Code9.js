let arr = ["One","Two","Three","Four","Five"];
console.log(arr.splice(2,0,"New","Another"));
console.log(arr);