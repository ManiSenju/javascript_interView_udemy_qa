let a=4*
5
console.log(a);