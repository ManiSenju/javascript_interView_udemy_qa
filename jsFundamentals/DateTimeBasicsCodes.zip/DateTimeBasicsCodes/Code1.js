const dt = new Date();
console.log(dt);