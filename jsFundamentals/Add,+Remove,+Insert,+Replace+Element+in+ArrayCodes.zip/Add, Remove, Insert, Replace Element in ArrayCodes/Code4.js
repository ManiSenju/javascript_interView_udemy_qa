let arr = ["One","Two","Three","Four","Five"];
console.log(arr.shift());
console.log(arr);