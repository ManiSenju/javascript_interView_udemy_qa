let arr = ["ES5","ES6","ES7","ES8"];
for(let i=0;i<arr.length;i++){
    console.log(arr[i]);
}