const {a=90,b} = {};
console.log(a,b);