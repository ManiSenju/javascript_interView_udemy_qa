let arr = ["ES5","ES6","ES7","ES8"];
for(let elem in arr){
    console.log(elem);
}