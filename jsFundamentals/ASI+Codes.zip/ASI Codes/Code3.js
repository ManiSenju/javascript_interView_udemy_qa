function test(){
    return 
    {
       a:5
    }
 }
 const obj=test();
 console.log(obj); 