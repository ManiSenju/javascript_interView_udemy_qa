let arr=[80,90,93,26];
let [a,,c,d] = arr;
console.log(a,c,d);