let arr=[16,25,36,144];
let nArr = arr.map((elem)=>{
  
    return Math.sqrt(elem);
})
console.log(nArr);