let arr=[4,6,8,10];
for( let i of arr){
   console.log(i);
}