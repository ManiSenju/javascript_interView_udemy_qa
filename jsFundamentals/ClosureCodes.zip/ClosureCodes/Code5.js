const addCounter=()=>{
    let counter=0;
    counter++;
    return counter;
}
console.log(addCounter());
console.log(addCounter());
console.log(addCounter());