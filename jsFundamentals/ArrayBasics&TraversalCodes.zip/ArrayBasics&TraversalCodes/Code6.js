let arr=[
    {pCode:1,pName:'Apple'},
    {pCode:2,pName:'Banana'},
    {pCode:3,pName:'Orange'}      
]
console.log(arr[0].pName);