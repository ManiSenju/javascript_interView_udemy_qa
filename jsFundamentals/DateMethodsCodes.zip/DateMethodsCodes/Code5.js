let dt = new Date();
dt.setDate(dt.getDate() - 50);
console.log( dt);