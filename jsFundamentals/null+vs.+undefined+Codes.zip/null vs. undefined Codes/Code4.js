let x=null;
let y;
console.log(x==y);