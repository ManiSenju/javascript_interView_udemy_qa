console.log(x);
let x;