let x=null;
console.log(x);