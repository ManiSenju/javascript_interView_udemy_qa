let arr=[4];
let [a,b=0]=arr;
console.log(a,b); 