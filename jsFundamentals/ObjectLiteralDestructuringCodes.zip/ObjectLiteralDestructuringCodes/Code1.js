const obj = {
    pCode:1001,
    pName:'Apple'
}
let {pCode,pName} = obj;
console.log(pCode,pName);