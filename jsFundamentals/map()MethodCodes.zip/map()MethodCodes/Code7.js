let products=[
    {pCode:1,pName:"Apple"},
    {pCode:2,pName:"Banana"},
    {pCode:3,pName:"Grapes"},
    {pCode:4,pName:"Oranges"}
]
let pNames = products.map(elem=>elem.pName);
console.log(pNames);  