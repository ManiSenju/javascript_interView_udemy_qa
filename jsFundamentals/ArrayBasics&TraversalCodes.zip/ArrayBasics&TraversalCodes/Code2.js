let arr = [4,7,9];
let arr1 = ["Hi",true,900];
console.log(arr);
console.log(arr1);
console.log(arr1.length);