let arr=["One","Two","One","Three","Four","One","Five"];
console.log(arr.indexOf("One"));
console.log(arr.indexOf("One",3));
console.log(arr.indexOf("one"));