let arr=[2,3,6,4,5];
let nArr = arr.map(elem=>{
    return elem*elem
});
console.log(nArr);