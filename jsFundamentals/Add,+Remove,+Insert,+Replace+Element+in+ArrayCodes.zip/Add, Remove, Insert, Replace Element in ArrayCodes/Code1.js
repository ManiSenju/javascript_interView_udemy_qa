let arr = ["One","Two","Three","Four","Five"];
console.log(arr.push("Six"));
console.log(arr);