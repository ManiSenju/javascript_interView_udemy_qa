let dt = new Date();
let arrMonths = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
console.log(arrMonths[dt.getMonth()]);