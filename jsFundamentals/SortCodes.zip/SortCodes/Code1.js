let products=["Banana","Orange","Grapes","Apple"];
let sArr = products.sort();
console.log(sArr);
console.log(products);