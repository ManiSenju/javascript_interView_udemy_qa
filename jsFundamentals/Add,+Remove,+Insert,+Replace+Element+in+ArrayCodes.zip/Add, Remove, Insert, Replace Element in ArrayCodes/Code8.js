let arr = ["One","Two","Three","Four","Five"];
console.log(arr.splice(2,1,"New","Another"));
console.log(arr);