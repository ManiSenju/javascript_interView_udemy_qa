let arr = ["ES5","ES6","ES7","ES8"];
arr.forEach((elem,index)=>{
    console.log(elem,index);
})