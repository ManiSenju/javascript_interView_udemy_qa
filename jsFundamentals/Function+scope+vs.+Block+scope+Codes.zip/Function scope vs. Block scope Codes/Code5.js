console.log(x);
var x=9;