let arr=[2,3,6,4,5];
arr.map(function(elem,index){
    console.log(elem,index);
});