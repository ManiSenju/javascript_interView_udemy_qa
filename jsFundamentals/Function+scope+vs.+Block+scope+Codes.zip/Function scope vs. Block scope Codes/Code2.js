let x=10; 
function a(){
      x=x+5;
  }
  function b(){
     console.log(x);
  }
  a()
  b();  