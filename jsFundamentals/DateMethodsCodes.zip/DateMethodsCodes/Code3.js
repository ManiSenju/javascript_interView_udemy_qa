let dt = Date.parse("2020-07-24");
console.log(dt);