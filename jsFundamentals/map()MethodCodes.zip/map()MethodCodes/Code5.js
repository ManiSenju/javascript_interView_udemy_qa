let arr=["Apple","Banana","Grapes","Oranges"];
let lArr = arr.map(elem=>elem.length);
console.log(lArr); 