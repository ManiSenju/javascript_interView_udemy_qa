let arr=[2,3,6,4,5];
let nArr = arr.map(function(elem,index){
    return elem*elem
});
console.log(nArr);