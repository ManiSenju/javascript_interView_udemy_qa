let arr = ["One","Two","Three","Four","Five"];
console.log(arr.splice(0));
console.log(arr);