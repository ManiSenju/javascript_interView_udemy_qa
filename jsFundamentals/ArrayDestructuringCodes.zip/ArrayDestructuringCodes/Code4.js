let a=4;
let b=5;
[a,b] = [b,a];
console.log(a,b);