let arr=[80,90,93,26];
let [a,b,c,d] = arr;
console.log(a,b,c,d);