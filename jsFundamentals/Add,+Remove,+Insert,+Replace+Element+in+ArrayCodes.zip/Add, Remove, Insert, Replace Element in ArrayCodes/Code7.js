let arr = ["One","Two","Three","Four","Five"];
console.log(arr.splice(2,1,"New"));
console.log(arr);