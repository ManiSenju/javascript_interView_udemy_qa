let x=9;
{
    let x=8;
    console.log(x);
}
console.log(x);