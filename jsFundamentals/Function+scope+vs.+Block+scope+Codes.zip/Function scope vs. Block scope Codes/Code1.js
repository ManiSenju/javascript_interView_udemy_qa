function a(){
    let x=10;   
  }
  function b(){
     console.log(x);
  }
  a()
  b();  