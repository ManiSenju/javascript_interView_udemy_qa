let arr=[4,5,6];
let [a,...b]=arr;
console.log(a,b); 