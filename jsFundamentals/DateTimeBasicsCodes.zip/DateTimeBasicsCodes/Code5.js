const dt = new Date("2020-08-23T12:00:00Z");
console.log(dt);