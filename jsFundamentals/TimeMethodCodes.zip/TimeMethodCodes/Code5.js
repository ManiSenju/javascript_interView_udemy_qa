let dt = new Date(2020,7,25);
let dt1 = new Date(2020,7,23);
let n = dt.getTime()-dt1.getTime();
n=(n/1000)/3600;
console.log(n);