let dt = new Date();
console.log(dt);
dt.setFullYear(2021);
console.log(dt);
dt.setMonth(09);
console.log(dt);
dt.setDate(12);
console.log(dt);