let arr=[2,3,6,4,5];
let nArr = arr.map((elem)=> elem*elem);
console.log(nArr);