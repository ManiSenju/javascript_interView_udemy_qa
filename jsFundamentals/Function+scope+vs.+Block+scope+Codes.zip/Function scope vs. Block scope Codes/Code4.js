console.log(x);
var x;