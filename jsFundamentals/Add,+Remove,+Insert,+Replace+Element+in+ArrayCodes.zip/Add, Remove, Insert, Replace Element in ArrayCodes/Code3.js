let arr = ["One","Two","Three","Four","Five"];
console.log(arr.pop());
console.log(arr);