let products=["Banana","Orange","Grapes","Apple"];
products.sort(function(a,b){
   console.log(a,b);
});
console.log(products);