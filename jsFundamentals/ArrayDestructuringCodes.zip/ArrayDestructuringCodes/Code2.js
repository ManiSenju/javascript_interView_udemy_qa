function test(){
    return [80,90,93,26];
}
let [a,b,c,d] = test();
console.log(a,b,c,d);