let arr = ["One","Two","Three","Four","Five"];
console.log(arr.splice(2));
console.log(arr);