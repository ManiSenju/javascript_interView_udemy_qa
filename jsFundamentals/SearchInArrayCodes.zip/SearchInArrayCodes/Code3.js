let arr=["One","Two","One","Three","Four","One","Five"];
console.log(arr.includes("One",3));