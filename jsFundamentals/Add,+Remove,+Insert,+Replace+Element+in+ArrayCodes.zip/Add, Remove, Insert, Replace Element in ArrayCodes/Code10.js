let arr = ["One","Two","Three","Four","Five"];
console.log(arr.splice(arr.length,0,"New"));
console.log(arr);