let x;
console.log(x);
console.log(typeof x);